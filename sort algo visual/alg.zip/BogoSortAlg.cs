﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace sort_algo_visual
{
    internal class BogoSortAlg : BaseSortAlg
    {
        private Random rand = new Random();

        public override List<Bar[]> Sort(Bar[] arrInit)
        {
            frames.Clear();
            Bar[] arr = (Bar[])arrInit.Clone();
            int attempts = 0;

            while (!IsSorted(arr) && attempts < 5000)
            {
                Shuffle(arr);
                frames.Add((Bar[])arr.Clone());
                attempts++;
            }

            return frames;
        }


        private void Shuffle(Bar[] arr)
        {
            for (int i = arr.Length - 1; i > 0; i--)
            {
                int k = rand.Next(i + 1);
                Bar temp = arr[i];
                arr[i] = arr[k];
                arr[k] = temp;
            }
        }
    }
}
