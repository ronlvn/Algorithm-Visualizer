﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sort_algo_visual
{
    internal struct Bar
    {
        public int Value;
        public Color BarColor;
    }
}
